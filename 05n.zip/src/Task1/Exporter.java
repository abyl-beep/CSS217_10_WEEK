package Task1;

interface Exporter {
    void export(String destination, String data);
}
