package Task4;

abstract class PricingDecorator implements PricingService {
    protected final PricingService wrappedService;

    public PricingDecorator(PricingService wrappedService) {
        if (wrappedService == null) throw new IllegalArgumentException("Wrapped service cannot be null");
        this.wrappedService = wrappedService;
    }

    @Override
    public double calculateTotal() {
        return wrappedService.calculateTotal();
    }

    @Override
    public String getReceiptBreakdown() {
        return wrappedService.getReceiptBreakdown();
    }
}

class GiftWrapDecorator extends PricingDecorator {
    public GiftWrapDecorator(PricingService wrapped) { super(wrapped); }

    @Override
    public double calculateTotal() {
        return super.calculateTotal() + 5.00;
    }

    @Override
    public String getReceiptBreakdown() {
        return super.getReceiptBreakdown() + " + [Gift Wrap: $5.00]";
    }
}
