package Task4;

public class LegacyForeignOrder {
    private final String orderId;
    private final double gbpAmount;

    public LegacyForeignOrder(String orderId, double gbpAmount) {
        this.orderId = orderId;
        this.gbpAmount = gbpAmount;
    }

    public String getOrderId() { return orderId; }
    public double getGbpAmount() { return gbpAmount; }
}

class LegacyCurrencyConverter {
    public double convert(double amount, String from, String to) {
        if ("GBP".equalsIgnoreCase(from) && "USD".equalsIgnoreCase(to)) {
            return amount * 1.25;
        }
        return amount;
    }
}
