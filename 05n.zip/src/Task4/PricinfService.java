package Task4;

interface PricingService {
    double calculateTotal();
    String getReceiptBreakdown();
}
