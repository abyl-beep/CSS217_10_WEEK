package Task2;

interface StockProvider {
    double getMarketPrice(String ticker);
    String getStatus(String ticker);
}
